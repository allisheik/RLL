export interface Card {
    id: number,
    title: String,
    imageUrl: String,
    price:number,
    seatscount:number
}
